# final_work_e-commerce
O trabalho final da cadeira de Programação Web 1, que consiste em:
 - Desenvolver um e-commerce para permitir a comercialização de produtos online.
Desenvolvedores:
 _Pedro Henrique Nascimento de Lima_, - 508892,
 _Guilherme Cavalcante Pires de Castro Studart_ - 509281,
 _Jonathan Oliveira Silva_ - 509013,
 _Edvando Ferreira Guilherme_ - 484852.

Tecnologias Utilizadas:
Html - Linguagem de marcação
CSS - Linguagem de estilização
Java - Backend
JavaScript - Validação de formulário login/cadastro
PostgreSQL - Linguagem de Banco de Dados.
